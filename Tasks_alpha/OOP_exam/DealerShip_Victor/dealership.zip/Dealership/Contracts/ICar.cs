﻿namespace Dealership.Contracts
{
    public interface ICar : IVehicle
    {
        int Seats { get; }
    }
}
