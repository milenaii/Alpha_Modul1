﻿namespace Dealership.Contracts
{
    public interface IMotorcycle : IVehicle
    {
        string Category { get; }
    }
}
