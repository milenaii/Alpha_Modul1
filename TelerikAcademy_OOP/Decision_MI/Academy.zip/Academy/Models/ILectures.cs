﻿namespace Academy.Models
{
    internal interface ILectures
    {
    }
}