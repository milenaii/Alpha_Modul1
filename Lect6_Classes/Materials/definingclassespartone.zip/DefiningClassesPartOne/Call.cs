﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefiningClassesPartOne
{
    public class Call
    {
        public DateTime DateTime
        {
            get;
            set;
        }

        public string DialedPhoneNumber
        {
            get;
            set;
        }

        public int DurationInSeconds
        {
            get;
            set;
        }
    }
}
