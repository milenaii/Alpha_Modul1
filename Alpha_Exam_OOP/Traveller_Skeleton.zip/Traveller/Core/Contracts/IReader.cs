﻿namespace Traveller.Core.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
