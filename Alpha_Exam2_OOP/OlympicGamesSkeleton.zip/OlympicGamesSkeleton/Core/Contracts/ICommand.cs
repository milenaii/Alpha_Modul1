﻿namespace OlympicGames.Core.Factories
{
    public interface ICommand
    {
        string Execute();
    }
}
