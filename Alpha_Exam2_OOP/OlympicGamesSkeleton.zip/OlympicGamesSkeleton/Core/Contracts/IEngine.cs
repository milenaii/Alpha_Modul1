﻿namespace OlympicGames.Core.Factories
{
    public interface IEngine
    {
        void Run();
    }
}
